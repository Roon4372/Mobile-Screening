#ifndef SC_VERSION_H
#define SC_VERSION_H

#include "common.h"

void
scrcpy_print_version(void);

#endif
